/**
 * @author indecomm
 * @license Copyright HMH
 */

import { Component } from '@angular/core';


// Defining the base component
@Component({
    selector:'commonui',
    template:'<h2>COMMON UI</h2>'
})

/**
 * Represents a class.
 * @class CommonUI
 */
export class CommonUI{

}