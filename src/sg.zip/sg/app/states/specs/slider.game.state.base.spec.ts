import { beforeEachProviders, describe, inject, async, it, expect } from '@angular/core/testing';
import { TestComponentBuilder } from '@angular/compiler/testing';
import { SliderGameStateBase } from '../slider.game.state.base';


/**
 * The main class of unit testing
 */
export function main() {

    /**
     * Unit testing for slider game engine
     */
    describe('Test Slider Game state base', ()=> {

        it('Testing engine method replaceVariableValues', ()=> {
          
        });

    });
}